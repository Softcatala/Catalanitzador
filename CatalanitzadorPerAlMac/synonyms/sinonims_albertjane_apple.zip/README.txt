Diccionari de sinònims - Albert Jané in Apple Dictionary format
==========================
Version: May 7 2017
This dictionary was converted from data available in http://sinonims.iec.cat

For more information about the dictionary, see http://sinonims.iec.cat/credits.asp


Copyright
==========================
Diccionari de sinònims - Albert Jané (c) by Institut d'Estudis Catalans

Diccionari de sinònims - Albert Jané is licensed under a
Creative Commons Reconeixement-NoComercial-SenseObraDerivada 3.0 (CC BY-NC-ND 3.0) License.

You should have received a copy of the license along with this
work.  If not, see <https://creativecommons.org/licenses/by-nc-nd/3.0/es/deed.ca>.

